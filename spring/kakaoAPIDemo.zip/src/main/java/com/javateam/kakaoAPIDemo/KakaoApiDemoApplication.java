package com.javateam.kakaoAPIDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakaoApiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KakaoApiDemoApplication.class, args);
	}

}
