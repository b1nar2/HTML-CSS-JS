package com.javateam.kakaoAPIDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakaoApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
